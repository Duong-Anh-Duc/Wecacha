"use client";

import Image from "next/image";
import {ArrowUpRight, Leaf} from "lucide-react";
import {AddToCartButton} from "@/components/cart/add-to-cart-button";
import {BuyNowButton} from "@/components/cart/buy-now-button";
import {Badge} from "@/components/ui/badge";
import {Button} from "@/components/ui/button";
import {Link} from "@/i18n/navigation";
import type {Locale} from "@/i18n/routing";
import type {Product} from "@/lib/content";
import {formatCurrency, localized} from "@/lib/content";

export function ProductCard({
  product,
  locale
}: {
  product: Product;
  locale: Locale;
}) {
  return (
    <article className="group flex h-full min-h-[680px] flex-col overflow-hidden rounded-md border border-forest-900/18 bg-gradient-to-b from-forest-950 via-forest-900 to-earth-900 text-white shadow-warm transition duration-500 hover:-translate-y-1 hover:shadow-cinematic">
      <Link
        href={`/shop/${product.slug}`}
        className="relative block aspect-[4/3] shrink-0 overflow-hidden bg-forest-900"
      >
        <Image
          src={product.images[0]}
          alt={localized(product.name, locale)}
          fill
          className="object-cover transition duration-[1400ms] ease-out group-hover:scale-[1.06]"
          sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-forest-950/72 via-forest-950/8 to-earth-700/10" />
        <Badge className="absolute left-4 top-4 border-white/24 bg-forest-950/42 text-parchment-50 backdrop-blur">
          <Leaf className="mr-1.5 h-3 w-3" aria-hidden="true" />
          {product.weight}
        </Badge>
      </Link>
      <div className="flex flex-1 flex-col p-5">
        <div className="grid min-h-[138px] grid-cols-[1fr_auto] gap-4">
          <div className="min-w-0">
            <h3 className="min-h-[64px] font-serif text-2xl leading-8 text-parchment-50">
              <Link href={`/shop/${product.slug}`} className="hover:text-ember">
                {localized(product.name, locale)}
              </Link>
            </h3>
            <p className="mt-3 line-clamp-3 text-sm leading-6 text-parchment-100/76">
              {localized(product.short, locale)}
            </p>
          </div>
          <p className="shrink-0 pt-1 text-right text-sm font-bold text-ember">
            {formatCurrency(product.price, locale)}
          </p>
        </div>

        <div className="mt-5 flex min-h-[82px] content-start flex-wrap gap-2">
          {localized(product.notes, locale)
            .slice(0, 3)
            .map((note) => (
              <span
                className="h-8 rounded-full border border-parchment-100/28 bg-parchment-50/6 px-3 py-1.5 text-xs font-medium text-parchment-100/82"
                key={note}
              >
                {note}
              </span>
            ))}
        </div>

        <div className="mt-auto grid grid-cols-2 gap-2 pt-6">
          <AddToCartButton
            product={product}
            locale={locale}
            variant="outline"
            className="w-full px-2 text-[13px] sm:text-sm"
          />
          <BuyNowButton product={product} className="w-full bg-forest-600 px-2 text-[13px] hover:bg-earth-600 sm:text-sm" />
        </div>

        <Button
          asChild
          variant="ghost"
          className="mt-4 h-10 w-full text-parchment-100 hover:bg-white/8 hover:text-ember"
        >
          <Link href={`/shop/${product.slug}`}>
            <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
            {localized(product.name, locale)}
          </Link>
        </Button>
      </div>
    </article>
  );
}
