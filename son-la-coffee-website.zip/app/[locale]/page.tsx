import {ArrowUpRight, Flame, Leaf, MapPinned} from "lucide-react";
import {getTranslations, setRequestLocale} from "next-intl/server";
import {CinematicImage} from "@/components/sections/cinematic-image";
import {SectionHeading} from "@/components/sections/section-heading";
import {ProductCard} from "@/components/shop/product-card";
import {Button} from "@/components/ui/button";
import {Reveal} from "@/components/motion/reveal";
import {CinematicHero} from "@/features/home/cinematic-hero";
import {TestimonialsCarousel} from "@/features/home/testimonials-carousel";
import {Link} from "@/i18n/navigation";
import type {Locale} from "@/i18n/routing";
import {
  imageLibrary,
  journeys,
  localized,
  products,
  storyChapters
} from "@/lib/content";

type Props = {
  params: Promise<{locale: Locale}>;
};

export default async function HomePage({params}: Props) {
  const {locale} = await params;
  setRequestLocale(locale);
  const t = await getTranslations({locale, namespace: "Home"});
  const common = await getTranslations({locale, namespace: "Common"});
  const featuredProducts = products.filter((product) => product.featured);

  return (
    <main>
      <CinematicHero
        kicker={t("kicker")}
        title={t("heroTitle")}
        copy={t("heroCopy")}
        primary={common("ctaShop")}
        secondary={common("ctaStory")}
        scrollLabel={t("scroll")}
      />

      <section className="bg-parchment-50 px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-center">
          <Reveal>
            <SectionHeading
              kicker="Origin"
              title={t("storyTitle")}
              copy={t("storyCopy")}
            />
            <div className="mt-9 grid gap-4 sm:grid-cols-3">
              {[
                {icon: Leaf, label: "1.050m+", value: "Altitude"},
                {icon: Flame, label: "Slow roast", value: "Handcrafted"},
                {icon: MapPinned, label: "Sơn La", value: "Northwest Vietnam"}
              ].map((item) => (
                <div
                  key={item.label}
                  className="border-t border-forest-950/14 pt-4"
                >
                  <item.icon className="h-5 w-5 text-earth-600" aria-hidden="true" />
                  <p className="mt-3 font-serif text-2xl">{item.label}</p>
                  <p className="text-xs uppercase text-forest-950/48">
                    {item.value}
                  </p>
                </div>
              ))}
            </div>
          </Reveal>
          <Reveal delay={0.12}>
            <div className="grid grid-cols-2 gap-3">
              <CinematicImage
                src={storyChapters[0].image}
                alt={localized(storyChapters[0].alt, locale)}
                className="aspect-[4/5]"
              />
              <CinematicImage
                src={imageLibrary.farmer}
                alt="Coffee farmer"
                className="mt-14 aspect-[4/5]"
              />
            </div>
          </Reveal>
        </div>
      </section>

      <section className="relative overflow-hidden bg-forest-950 px-4 py-20 text-white sm:px-6 lg:px-8 lg:py-28">
        <div className="absolute inset-0 opacity-45">
          <CinematicImage
            src={imageLibrary.campfire}
            alt=""
            className="h-full rounded-none shadow-none"
            sizes="100vw"
          />
        </div>
        <div className="relative mx-auto grid max-w-7xl gap-10 lg:grid-cols-[1fr_0.8fr] lg:items-end">
          <Reveal>
            <SectionHeading
              light
              kicker="Culture"
              title={t("cultureTitle")}
              copy={t("cultureCopy")}
            />
          </Reveal>
          <Reveal delay={0.15}>
            <blockquote className="border-y border-white/14 py-8 font-serif text-3xl leading-tight text-parchment-50">
              {localized(storyChapters[2].body, locale)[0]}
            </blockquote>
          </Reveal>
        </div>
      </section>

      <section className="bg-forest-900 px-4 py-20 text-white sm:px-6 lg:px-8 lg:py-28">
        <div className="mx-auto max-w-7xl">
          <div className="mb-10 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <Reveal>
              <SectionHeading
                light
                kicker="Shop"
                title={t("productsTitle")}
              />
            </Reveal>
            <Button asChild variant="outline">
              <Link href="/shop">
                {common("viewAll")}
                <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>
          </div>
          <div className="grid gap-5 md:grid-cols-3">
            {featuredProducts.map((product) => (
              <ProductCard key={product.slug} product={product} locale={locale} />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-parchment-50 px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="mx-auto max-w-7xl">
          <Reveal>
            <SectionHeading
              kicker="Journeys"
              title={t("journeysTitle")}
              align="center"
            />
          </Reveal>
          <div className="mt-12 grid gap-4 lg:grid-cols-3">
            {journeys.map((journey, index) => (
              <Reveal delay={index * 0.08} key={localized(journey.title, locale)}>
                <Link
                  href={journey.href}
                  className="group block overflow-hidden rounded-md bg-forest-950 text-white shadow-warm"
                >
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <CinematicImage
                      src={journey.image}
                      alt={localized(journey.title, locale)}
                      className="h-full rounded-none shadow-none"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="font-serif text-3xl leading-none group-hover:text-ember">
                      {localized(journey.title, locale)}
                    </h3>
                    <p className="mt-3 text-sm leading-6 text-white/62">
                      {localized(journey.body, locale)}
                    </p>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-paper-grain px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="mx-auto max-w-7xl">
          <Reveal>
            <SectionHeading
              kicker="Testimonials"
              title={t("testimonialsTitle")}
            />
          </Reveal>
          <div className="mt-10">
            <TestimonialsCarousel locale={locale} />
          </div>
        </div>
      </section>
    </main>
  );
}
