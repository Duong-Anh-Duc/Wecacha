import type {Metadata} from "next";
import {getTranslations, setRequestLocale} from "next-intl/server";
import {CinematicPageHero} from "@/components/sections/cinematic-page-hero";
import {ExploreExperience} from "@/features/explore/explore-experience";
import type {Locale} from "@/i18n/routing";
import {imageLibrary} from "@/lib/content";

type Props = {
  params: Promise<{locale: Locale}>;
};

export async function generateMetadata({params}: Props): Promise<Metadata> {
  const {locale} = await params;
  const t = await getTranslations({locale, namespace: "Explore"});

  return {
    title: t("title"),
    description: t("intro"),
    alternates: {
      canonical: `/${locale}/explore`,
      languages: {
        vi: "/vi/explore",
        en: "/en/explore"
      }
    }
  };
}

export default async function ExplorePage({params}: Props) {
  const {locale} = await params;
  setRequestLocale(locale);
  const t = await getTranslations({locale, namespace: "Explore"});

  return (
    <main className="bg-parchment-50">
      <CinematicPageHero
        kicker="Explore"
        title={t("title")}
        copy={t("intro")}
        image={imageLibrary.mountains}
        imageAlt="Northwest Vietnam mountains in mist"
        chips={[
          locale === "vi" ? "Nương cà phê trong sương" : "Coffee farms in fog",
          locale === "vi" ? "Văn hóa dân tộc và thổ cẩm" : "Ethnic culture and brocade",
          locale === "vi" ? "Bản đồ vùng trồng Sơn La" : "Son La growing map"
        ]}
      />
      <section className="px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
        <div className="mx-auto max-w-7xl">
          <ExploreExperience
            locale={locale}
            labels={{
              gallery: t("gallery"),
              reels: t("reels"),
              mapTitle: t("mapTitle")
            }}
          />
        </div>
      </section>
    </main>
  );
}
