import type {Metadata} from "next";
import {getTranslations, setRequestLocale} from "next-intl/server";
import {CinematicImage} from "@/components/sections/cinematic-image";
import {CinematicPageHero} from "@/components/sections/cinematic-page-hero";
import {Reveal} from "@/components/motion/reveal";
import {ShopGrid} from "@/features/shop/shop-grid";
import type {Locale} from "@/i18n/routing";
import {imageLibrary, products} from "@/lib/content";

type Props = {
  params: Promise<{locale: Locale}>;
};

export async function generateMetadata({params}: Props): Promise<Metadata> {
  const {locale} = await params;
  const t = await getTranslations({locale, namespace: "Shop"});

  return {
    title: t("title"),
    description: t("intro"),
    alternates: {
      canonical: `/${locale}/shop`,
      languages: {
        vi: "/vi/shop",
        en: "/en/shop"
      }
    }
  };
}

export default async function ShopPage({params}: Props) {
  const {locale} = await params;
  setRequestLocale(locale);
  const t = await getTranslations({locale, namespace: "Shop"});

  return (
    <main className="bg-parchment-50">
      <CinematicPageHero
        kicker="Coffee shop"
        title={t("title")}
        copy={t("intro")}
        image={imageLibrary.farm}
        imageAlt="Coffee farm in misty mountains"
        chips={[
          locale === "vi" ? "Hạt rang trên triền đồi 1.000m" : "Beans from 1,000m hillsides",
          locale === "vi" ? "Rang chậm, hậu ngọt dịu" : "Slow roasted, soft sweet finish",
          locale === "vi" ? "Quà tặng mang sắc thổ cẩm" : "Gift sets with brocade color"
        ]}
      />

      <section className="bg-forest-950 px-4 py-10 text-white sm:px-6 lg:px-8">
        <div className="film-strip mx-auto grid max-w-7xl grid-cols-3 gap-3 md:grid-cols-5">
          {[imageLibrary.beans, imageLibrary.roasted, imageLibrary.phin, imageLibrary.packaging, imageLibrary.cup].map(
            (image, index) => (
              <Reveal delay={index * 0.04} key={image}>
                <CinematicImage
                  src={image}
                  alt=""
                  className="cinematic-float aspect-[4/3] rounded-sm shadow-none"
                  sizes="(min-width: 1024px) 20vw, 33vw"
                />
              </Reveal>
            )
          )}
        </div>
      </section>

      <section className="px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="mx-auto max-w-7xl">
          <ShopGrid products={products} locale={locale} />
        </div>
      </section>
    </main>
  );
}
