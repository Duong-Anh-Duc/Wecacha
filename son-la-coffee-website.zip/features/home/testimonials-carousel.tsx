"use client";

import {useCallback} from "react";
import useEmblaCarousel from "embla-carousel-react";
import {ChevronLeft, ChevronRight, Quote} from "lucide-react";
import {Button} from "@/components/ui/button";
import type {Locale} from "@/i18n/routing";
import {testimonials, localized} from "@/lib/content";

export function TestimonialsCarousel({locale}: {locale: Locale}) {
  const [emblaRef, emblaApi] = useEmblaCarousel({
    align: "start",
    loop: true
  });

  const scrollPrev = useCallback(() => emblaApi?.scrollPrev(), [emblaApi]);
  const scrollNext = useCallback(() => emblaApi?.scrollNext(), [emblaApi]);

  return (
    <div className="relative">
      <div className="overflow-hidden" ref={emblaRef}>
        <div className="flex gap-5">
          {testimonials.map((item) => (
            <figure
              key={item.name}
              className="min-w-0 flex-[0_0_88%] rounded-md border border-forest-950/10 bg-parchment-50 p-6 shadow-warm sm:flex-[0_0_48%] lg:flex-[0_0_32%]"
            >
              <Quote className="h-7 w-7 text-earth-600" aria-hidden="true" />
              <blockquote className="mt-6 font-serif text-3xl leading-tight text-forest-950">
                {localized(item.quote, locale)}
              </blockquote>
              <figcaption className="mt-7 text-sm text-forest-950/62">
                <strong className="block text-forest-950">{item.name}</strong>
                {localized(item.role, locale)}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
      <div className="mt-5 flex justify-end gap-2">
        <Button size="icon" variant="light" onClick={scrollPrev} aria-label="Previous testimonial">
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <Button size="icon" variant="light" onClick={scrollNext} aria-label="Next testimonial">
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
